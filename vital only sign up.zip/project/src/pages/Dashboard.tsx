import { Heart, Activity, Thermometer, Gauge } from 'lucide-react';

export function Dashboard() {
  return (
    <div className="ml-64 p-8 w-full">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-semibold text-gray-800">Heart Monitoring</h1>
        <div className="flex gap-4">
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
            <Activity className="w-5 h-5 text-[#FF6B6B] mr-2" />
            Export Data
          </button>
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
            <Heart className="w-5 h-5 text-[#FF6B6B] mr-2" />
            Share
          </button>
        </div>
      </div>

      <div className="bg-gradient-to-r from-[#FF6B6B] to-[#FF8E8E] rounded-2xl p-10 text-white mb-8 relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-3xl font-bold mb-4">Real-Time Heart Monitoring</h2>
          <p className="text-lg opacity-90 mb-6">
            Track your heart health metrics with precision and convenience. Our advanced sensors provide
            accurate real-time data to help you maintain optimal health.
          </p>
          <button className="bg-white text-[#FF6B6B] px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all">
            View Detailed Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: Heart, label: 'ECG Signal', value: 'Normal', status: 'Healthy' },
          { icon: Activity, label: 'SpO₂ Level', value: '98%', status: 'Normal' },
          { icon: Thermometer, label: 'Temperature', value: '98.6°F', status: 'Normal' },
          { icon: Gauge, label: 'Heart Rate', value: '72 BPM', status: 'Resting' },
        ].map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 bg-[#fff5f5] rounded-lg flex items-center justify-center mb-4">
                <Icon className="w-6 h-6 text-[#FF6B6B]" />
              </div>
              <h4 className="text-gray-600 text-sm mb-2">{item.label}</h4>
              <p className="text-2xl font-bold text-gray-800 mb-2">{item.value}</p>
              <span className="inline-block px-3 py-1 bg-green-50 text-green-600 rounded-full text-sm">
                {item.status}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}