import { Bell, AlertCircle } from 'lucide-react';

export function Alerts() {
  const alerts = [
    {
      id: 1,
      title: 'Health Report Ready',
      message: 'Your weekly health report is ready to view.',
      time: '5 minutes ago',
      isUnread: true,
    },
    {
      id: 2,
      title: 'System Update',
      message: 'VitalSync has been updated to version 2.0 with new features.',
      time: '1 hour ago',
      isUnread: false,
    },
    {
      id: 3,
      title: 'Heart Rate Alert',
      message: 'Your heart rate was above normal for 5 minutes.',
      time: '2 hours ago',
      isUnread: true,
    },
  ];

  return (
    <div className="ml-64 p-8 w-full">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-semibold text-gray-800">Notifications</h1>
        <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
          <Bell className="w-5 h-5 text-[#FF6B6B] mr-2" />
          Mark All as Read
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-6">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`border-b border-gray-100 last:border-0 py-4 ${
                alert.isUnread ? 'bg-gray-50' : ''
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-[#fff5f5] rounded-lg flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="w-5 h-5 text-[#FF6B6B]" />
                </div>
                <div className="flex-1">
                  <h3 className="text-gray-800 font-medium">{alert.title}</h3>
                  <p className="text-gray-600 text-sm mt-1">{alert.message}</p>
                  <span className="text-gray-400 text-xs mt-2 block">{alert.time}</span>
                </div>
                {alert.isUnread && (
                  <div className="w-2 h-2 bg-[#FF6B6B] rounded-full flex-shrink-0"></div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}