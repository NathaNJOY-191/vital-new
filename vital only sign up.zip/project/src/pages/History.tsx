import { Activity, Download, Filter } from 'lucide-react';

export function History() {
  const healthRecords = [
    {
      date: 'Mar 10, 2025',
      time: '09:30 AM',
      ecg: 'Normal',
      heartRate: '72 BPM',
      spo2: '98%',
      temperature: '98.6°F',
      status: 'Normal',
    },
    {
      date: 'Mar 09, 2025',
      time: '10:15 AM',
      ecg: 'Normal',
      heartRate: '74 BPM',
      spo2: '97%',
      temperature: '98.4°F',
      status: 'Normal',
    },
    {
      date: 'Mar 08, 2025',
      time: '08:45 AM',
      ecg: 'Irregular',
      heartRate: '88 BPM',
      spo2: '96%',
      temperature: '99.1°F',
      status: 'Warning',
    },
  ];

  return (
    <div className="ml-64 p-8 w-full">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-semibold text-gray-800">Health History</h1>
        <div className="flex gap-4">
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
            <Download className="w-5 h-5 text-[#FF6B6B] mr-2" />
            Export Data
          </button>
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
            <Filter className="w-5 h-5 text-[#FF6B6B] mr-2" />
            Filter
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Date & Time</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">ECG</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Heart Rate</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">SpO₂</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Temperature</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Status</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Action</th>
            </tr>
          </thead>
          <tbody>
            {healthRecords.map((record, index) => (
              <tr key={index} className="border-t border-gray-100">
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-900">{record.date}</div>
                  <div className="text-sm text-gray-500">{record.time}</div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">{record.ecg}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{record.heartRate}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{record.spo2}</td>
                <td className="px-6 py-4 text-sm text-gray-900">{record.temperature}</td>
                <td className="px-6 py-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      record.status === 'Normal'
                        ? 'bg-green-50 text-green-600'
                        : 'bg-yellow-50 text-yellow-600'
                    }`}
                  >
                    {record.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-sm text-[#FF6B6B] hover:text-[#ff5252]">View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}