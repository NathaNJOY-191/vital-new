import { useState, useEffect } from 'react';
import { Heart, Activity, Thermometer, Gauge } from 'lucide-react';

export function LiveData() {
  const [vitals, setVitals] = useState({
    heartRate: '72',
    spo2: '98',
    temperature: '98.6',
    bloodPressure: '120/80'
  });

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setVitals(prev => ({
        heartRate: (parseInt(prev.heartRate) + Math.floor(Math.random() * 3) - 1).toString(),
        spo2: (parseInt(prev.spo2) + (Math.random() > 0.7 ? (Math.random() > 0.5 ? 1 : -1) : 0)).toString(),
        temperature: (parseFloat(prev.temperature) + (Math.random() - 0.5) * 0.2).toFixed(1),
        bloodPressure: prev.bloodPressure
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="ml-64 p-8 w-full">
      <div className="header">
        <h1 className="text-3xl font-semibold text-gray-800">Live Data Monitoring</h1>
        <div className="flex gap-4 mt-4">
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
            <Activity className="w-5 h-5 text-[#FF6B6B] mr-2" />
            Export Data
          </button>
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow">
            <Heart className="w-5 h-5 text-[#FF6B6B] mr-2" />
            Print Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="w-12 h-12 bg-[#fff5f5] rounded-lg flex items-center justify-center mb-4">
            <Heart className="w-6 h-6 text-[#FF6B6B]" />
          </div>
          <h4 className="text-gray-600 text-sm mb-2">Heart Rate</h4>
          <p className="text-2xl font-bold text-gray-800 mb-2">{vitals.heartRate} BPM</p>
          <span className="inline-block px-3 py-1 bg-green-50 text-green-600 rounded-full text-sm">
            Normal
          </span>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="w-12 h-12 bg-[#fff5f5] rounded-lg flex items-center justify-center mb-4">
            <Activity className="w-6 h-6 text-[#FF6B6B]" />
          </div>
          <h4 className="text-gray-600 text-sm mb-2">SpO₂ Level</h4>
          <p className="text-2xl font-bold text-gray-800 mb-2">{vitals.spo2}%</p>
          <span className="inline-block px-3 py-1 bg-green-50 text-green-600 rounded-full text-sm">
            Normal
          </span>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="w-12 h-12 bg-[#fff5f5] rounded-lg flex items-center justify-center mb-4">
            <Thermometer className="w-6 h-6 text-[#FF6B6B]" />
          </div>
          <h4 className="text-gray-600 text-sm mb-2">Temperature</h4>
          <p className="text-2xl font-bold text-gray-800 mb-2">{vitals.temperature}°F</p>
          <span className="inline-block px-3 py-1 bg-green-50 text-green-600 rounded-full text-sm">
            Normal
          </span>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm">
          <div className="w-12 h-12 bg-[#fff5f5] rounded-lg flex items-center justify-center mb-4">
            <Gauge className="w-6 h-6 text-[#FF6B6B]" />
          </div>
          <h4 className="text-gray-600 text-sm mb-2">Blood Pressure</h4>
          <p className="text-2xl font-bold text-gray-800 mb-2">{vitals.bloodPressure}</p>
          <span className="inline-block px-3 py-1 bg-green-50 text-green-600 rounded-full text-sm">
            Normal
          </span>
        </div>
      </div>

      <div className="mt-8 bg-white p-6 rounded-xl shadow-sm">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">ECG Monitor</h2>
        <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400">
          ECG Visualization Placeholder
        </div>
      </div>
    </div>
  );
}