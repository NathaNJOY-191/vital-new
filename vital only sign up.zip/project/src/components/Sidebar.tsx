import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Heart, Activity, Bell, History, User, Settings, LogOut } from 'lucide-react';

export function Sidebar() {
  const [showPopup, setShowPopup] = useState(false);
  const location = useLocation();

  const menuItems = [
    { path: '/', icon: Activity, label: 'Dashboard' },
    { path: '/live', icon: Heart, label: 'Live Data' },
    { path: '/alerts', icon: Bell, label: 'Alerts' },
    { path: '/history', icon: History, label: 'History' },
  ];

  return (
    <div className="w-64 h-screen bg-white p-8 fixed left-0 top-0 shadow-lg flex flex-col">
      <div className="flex items-center mb-10">
        <Heart className="text-[#FF6B6B] w-6 h-6" />
        <h2 className="text-2xl font-bold ml-3 text-[#FF6B6B]">VitalSync</h2>
      </div>

      <ul className="flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <li key={item.path} className="mb-2">
              <Link
                to={item.path}
                className={`flex items-center px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-[#FF6B6B] text-white shadow-md'
                    : 'text-gray-600 hover:bg-[#fff5f5] hover:text-[#FF6B6B]'
                }`}
              >
                <Icon className="w-5 h-5 mr-3" />
                <span className="font-medium">{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>

      <div className="relative">
        <div
          className="flex items-center p-4 border-t border-gray-100 cursor-pointer"
          onClick={() => setShowPopup(!showPopup)}
        >
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=faces"
            alt="User"
            className="w-10 h-10 rounded-full"
          />
          <div className="ml-3">
            <h4 className="text-sm font-semibold text-gray-700">John Doe</h4>
            <p className="text-xs text-gray-500">Patient</p>
          </div>
        </div>

        {showPopup && (
          <div className="absolute bottom-full left-4 w-48 bg-white rounded-lg shadow-lg py-2 mb-2">
            <Link to="/profile" className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100">
              <User className="w-4 h-4 mr-2" />
              Profile
            </Link>
            <Link to="/settings" className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Link>
            <Link to="/register" className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}